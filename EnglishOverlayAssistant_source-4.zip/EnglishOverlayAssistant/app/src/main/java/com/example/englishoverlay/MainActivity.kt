package com.example.englishoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        box.addView(TextView(this).apply {
            text = "英语悬浮助手 0.1\n\n识别成功后，悬浮窗会显示候选单词。点击“开始朗读”可播放一次标准英语发音。"
            textSize = 18f
        })
        box.addView(Button(this).apply {
            text = "① 开启悬浮窗权限"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        box.addView(Button(this).apply {
            text = "② 开启屏幕文字读取服务"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "③ 显示悬浮窗"
            setOnClickListener { startService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        box.addView(TextView(this).apply {
            text = "\n说明：此版本读取无障碍树中可访问的文字，不截屏、不上传屏幕内容。部分小程序页面可能不暴露文字；这种情况下需要后续增加用户主动授权的屏幕 OCR。"
            textSize = 14f
        })
        setContentView(box)
    }
}
