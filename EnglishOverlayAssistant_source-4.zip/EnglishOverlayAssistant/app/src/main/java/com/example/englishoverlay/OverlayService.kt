package com.example.englishoverlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class OverlayService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var wordView: TextView? = null
    private var statusView: TextView? = null
    private var tts: TextToSpeech? = null
    private var currentWord = ""
    private var ready = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(0xEE172638.toInt())
        }
        root.addView(TextView(this).apply {
            text = "AI 英语助手"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
        })
        wordView = TextView(this).apply {
            text = "等待识别单词…"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 18, 0, 12)
        }
        root.addView(wordView)
        statusView = TextView(this).apply {
            text = "识别成功后可点击朗读"
            setTextColor(0xFFB9D8F0.toInt())
        }
        root.addView(statusView)
        root.addView(Button(this).apply {
            text = "开始朗读（1遍）"
            setOnClickListener {
                if (currentWord.isNotBlank() && ready) {
                    statusView?.text = "正在朗读…"
                    tts?.speak(currentWord, TextToSpeech.QUEUE_FLUSH, null, "word_once")
                }
            }
        })
        root.addView(Button(this).apply {
            text = "关闭悬浮窗"
            setOnClickListener { stopSelf() }
        })
        panel = root
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 180 }
        if (android.provider.Settings.canDrawOverlays(this)) wm.addView(root, params)
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            val result = tts?.setLanguage(Locale.US)
            statusView?.text = if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) "请安装英语语音数据" else "美式英语 · 正常速度 · 1遍"
        }
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        @Volatile private var instance: OverlayService? = null
        fun updateWord(word: String) {
            // Accessibility service calls this on the same process.
            instance?.setWord(word)
        }
    }
    private fun setWord(word: String) {
        if (word.equals(currentWord, ignoreCase = true)) return
        currentWord = word
        wordView?.text = word
        statusView?.text = "识别成功：$word"
    }
}
