package com.example.englishoverlay

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class WordAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val candidates = mutableListOf<String>()
        collectText(root, candidates)
        // Conservative heuristic: only short, alphabetic tokens; ignore common UI labels.
        val ignored = setOf("continue", "next", "submit", "record", "start", "stop",
            "listen", "microphone", "settings", "home", "back", "english")
        val word = candidates.asSequence()
            .flatMap { it.trim().split(Regex("\\s+")).asSequence() }
            .map { it.trim().trim(',', '.', '!', '?', ':', ';', '(', ')', '[', ']') }
            .firstOrNull {
                it.length in 2..18 && it.all { ch -> ch.isLetter() && ch.code < 128 } &&
                    it.lowercase(Locale.US) !in ignored
            }
        if (!word.isNullOrBlank()) OverlayService.updateWord(word)
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            collectText(child, out)
            child.recycle()
        }
    }
    override fun onInterrupt() {}
}
